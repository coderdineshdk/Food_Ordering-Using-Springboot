package com.zosh.request;

import lombok.Data;

@Data
public class UpdateCartItemRequest {
	
	private Long cartItemId;
	private int quantity;
	public int getQuantity() {
		// TODO Auto-generated method stub
		return 0;
	}
	public Long getCartItemId() {
		// TODO Auto-generated method stub
		return null;
	}

}
