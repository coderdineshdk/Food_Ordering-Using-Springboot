package com.zosh.response;


import com.zosh.domain.USER_ROLE;
import lombok.Data;

@Data
public class AuthResponse {
	
	private String message;
	private String jwt;
	private USER_ROLE role;
	public void setRole(USER_ROLE valueOf) {
		// TODO Auto-generated method stub
		
	}
	public void setJwt(String token) {
		// TODO Auto-generated method stub
		
	}
	public void setMessage(String string) {
		// TODO Auto-generated method stub
		
	}
	


}
