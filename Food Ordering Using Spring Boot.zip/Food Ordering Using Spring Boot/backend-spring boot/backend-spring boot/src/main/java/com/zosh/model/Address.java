package com.zosh.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Address {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	private String fullName;

	private String streetAddress;

	private String city;

	private String state;

	private String postalCode;

	private String country;

	public void setCity(Class<? extends Object> class1) {
		// TODO Auto-generated method stub
		
	}

	public void setFullName(String fullName2) {
		// TODO Auto-generated method stub
		
	}

	public void setCity(String simpleName) {
		// TODO Auto-generated method stub
		
	}

	public Object getCountry() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setCountry(Object country2) {
		// TODO Auto-generated method stub
		
	}

	public Object getPostalCode() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setPostalCode(Object postalCode2) {
		// TODO Auto-generated method stub
		
	}

	public Object getState() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setState(Object state2) {
		// TODO Auto-generated method stub
		
	}

	public Object getStreetAddress() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setStreetAddress(Object streetAddress2) {
		// TODO Auto-generated method stub
		
	}

}
