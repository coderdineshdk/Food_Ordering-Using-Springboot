package com.zosh.request;

import com.zosh.model.Address;

import lombok.Data;

@Data
public class CreateOrderRequest {
 
	private Long restaurantId;
	
	private Address deliveryAddress;

	public Address getDeliveryAddress() {
		// TODO Auto-generated method stub
		return null;
	}

	public Long getRestaurantId() {
		// TODO Auto-generated method stub
		return null;
	}
	
    
}
