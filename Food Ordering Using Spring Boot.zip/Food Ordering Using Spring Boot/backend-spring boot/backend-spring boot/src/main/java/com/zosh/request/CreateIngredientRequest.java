package com.zosh.request;

import lombok.Data;

@Data
public class CreateIngredientRequest {

    private Long restaurantId;
    private String name;
    private Long ingredientCategoryId;
	public Long getRestaurantId() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getName() {
		// TODO Auto-generated method stub
		return null;
	}
	public Long getIngredientCategoryId() {
		// TODO Auto-generated method stub
		return null;
	}
}
