package com.zosh.request;

import lombok.Data;

@Data
public class LoginRequest {
	
	private String email;
	private String password;
	public String getPassword() {
		// TODO Auto-generated method stub
		return null;
	}
	public String getEmail() {
		// TODO Auto-generated method stub
		return null;
	}
	


}
