package com.zosh.model;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Events {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	private String image;
	
	private String startedAt;
	
	private String endsAt;
	
	private String name;
	
	@ManyToOne
	private Restaurant restaurant;
	
	private String location;

	public void setRestaurant(Restaurant restaurant2) {
		// TODO Auto-generated method stub
		
	}

	public Object getImage() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setImage(Object image2) {
		// TODO Auto-generated method stub
		
	}

	public Object getName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setName(Object name2) {
		// TODO Auto-generated method stub
		
	}

	public Object getLocation() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setLocation(Object location2) {
		// TODO Auto-generated method stub
		
	}

	public Object getEndsAt() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setEndsAt(Object endsAt2) {
		// TODO Auto-generated method stub
		
	}

	public Object getStartedAt() {
		// TODO Auto-generated method stub
		return null;
	}

	public void setStartedAt(Object startedAt2) {
		// TODO Auto-generated method stub
		
	}

}
