package com.zosh.model;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
public class Food {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String name;
    private String description;
    private Long price;
    
    @ManyToOne
    private Category foodCategory;


    @ElementCollection
    @Column(length = 1000)
    private List<String> images;

    private boolean available;

//    @JsonIgnore
    @ManyToOne
    private Restaurant restaurant;
    
    private boolean isVegetarian;
    private boolean isSeasonal;
    
    @ManyToMany
    private List<IngredientsItem> ingredients=new ArrayList<>();

    @Temporal(TemporalType.TIMESTAMP)
    private Date creationDate;

	public int getPrice() {
		// TODO Auto-generated method stub
		return 0;
	}

	public void setFoodCategory(Category category) {
		// TODO Auto-generated method stub
		
	}

	public void setCreationDate(Date date) {
		// TODO Auto-generated method stub
		
	}

	public void setDescription(Object description2) {
		// TODO Auto-generated method stub
		
	}

	public void setImages(Object images2) {
		// TODO Auto-generated method stub
		
	}

	public void setName(Object name2) {
		// TODO Auto-generated method stub
		
	}

	public void setPrice(long price2) {
		// TODO Auto-generated method stub
		
	}

	public void setSeasonal(Object seasonal) {
		// TODO Auto-generated method stub
		
	}

	public void setVegetarian(Object vegetarian) {
		// TODO Auto-generated method stub
		
	}

	public void setIngredients(Object ingredients2) {
		// TODO Auto-generated method stub
		
	}

	public void setRestaurant(Restaurant restaurant2) {
		// TODO Auto-generated method stub
		
	}

	public boolean isVegetarian() {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean isSeasonal() {
		// TODO Auto-generated method stub
		return false;
	}

	public Object getFoodCategory() {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean isAvailable() {
		// TODO Auto-generated method stub
		return false;
	}

	public void setAvailable(boolean b) {
		// TODO Auto-generated method stub
		
	}


    
}
