package com.zosh.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class ApiResponse {
	
	public ApiResponse(String string, boolean b) {
		// TODO Auto-generated constructor stub
	}
	public ApiResponse() {
		// TODO Auto-generated constructor stub
	}
	private String message;
	private boolean status;
	public void setMessage(String string) {
		// TODO Auto-generated method stub
		
	}
	public void setStatus(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
