package com.zosh.request;



import java.util.List;

import com.zosh.model.Category;
import com.zosh.model.IngredientsItem;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CreateFoodRequest {
	

    
    private String name;
    private String description;
    private Long price;
    
  
    private Category category;
    private List<String> images;

   
    private Long restaurantId;
    
    private boolean vegetarian;
    private boolean seasonal;
    
    
    private List<IngredientsItem> ingredients;


	public Long getCategoryId() {
		// TODO Auto-generated method stub
		return null;
	}


	public Long getRestaurantId() {
		// TODO Auto-generated method stub
		return null;
	}


	public Category getCategory() {
		// TODO Auto-generated method stub
		return null;
	}


	public Long getCategoryId1() {
		// TODO Auto-generated method stub
		return null;
	}


	public Object getDescription() {
		// TODO Auto-generated method stub
		return null;
	}


	public Object getImages() {
		// TODO Auto-generated method stub
		return null;
	}


	public Object getName() {
		// TODO Auto-generated method stub
		return null;
	}


	public long getPrice() {
		// TODO Auto-generated method stub
		return 0;
	}


	public Object isSeasonal() {
		// TODO Auto-generated method stub
		return null;
	}


	public Object isVegetarian() {
		// TODO Auto-generated method stub
		return null;
	}


	public Object getIngredients() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
