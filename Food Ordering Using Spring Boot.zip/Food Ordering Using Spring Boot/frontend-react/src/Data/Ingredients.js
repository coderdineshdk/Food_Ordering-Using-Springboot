export const ingredients=[
    {
        ingredientCategory:"bread",
        ingredientName:"white Bread"
    },
    {
        ingredientCategory:"bread",
        ingredientName:"red Bread"
    },
    {
        ingredientCategory:"souce",
        ingredientName:"tomato souce"
    },
    {
        ingredientCategory:"souce",
        ingredientName:"onion souce"
    }
]